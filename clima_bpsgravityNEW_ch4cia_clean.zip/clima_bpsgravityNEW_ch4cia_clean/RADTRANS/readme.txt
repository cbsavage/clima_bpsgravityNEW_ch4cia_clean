CLIMA/RADTRANS

This subdirectory contains the subroutines that calculate the fluxes in the 
visible/near IR and IR.

The IR subroutine is only used when the capability of RRTM is exceeded,
that is when mixing ratio of CO2 is more than the one that RRTM can 
accurately manage. This may happen too with other gases like methane. 
Check the capabilities of RRTM in its website before doing extreme atmospheres.

