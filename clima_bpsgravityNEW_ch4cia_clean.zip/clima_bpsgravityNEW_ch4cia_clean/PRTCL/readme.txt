CLIMA/PRTCL

This subdirectory contains the subroutines to consider the absorption by 
particles and aereosols in the atmosphere