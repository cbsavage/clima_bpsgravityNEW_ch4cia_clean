 % This program reads inner edge output files and generates various plots.
%clear all;clc

[TGO SEFF PALB FH2O FTIR FTSO]=textread('MarsH2runawayReview.325', '%f %f %f %f %f %f', 25, 'headerlines',1)

FNET = FTIR - FTSO



%plot(TGO,PALB,'rx-')
%title('RUNAWAY GREENHOUSE ALBEDO VS. SURFACE TEMP')
%xlabel('Surface Temperature (K)')
%ylabel('Planetary Albedo')
%axis([200 620 0.08 .3])
%pause
%hold on

plot(TGO,FTIR,'rx-')
%hold on
%plot(TGO,FTSO,'bx-')
title('Net OUTGOING THERMAL AND INCOMING SOLAR FLUXES')
xlabel('Surface Temperature (K)')
ylabel('Flux (W/m^2)')

%axis([200 700 200 320])
%hold off
%pause

%plot(TGO,SEFF,'rx-')
%xlabel('Surface Temperature (K)')
%ylabel('S_e_f_f')
%axis([200 1500 0.5 2.])

%pause
%semilogy(SEFF, FH2O,'rx-')
%xlabel('S_e_f_f')
%ylabel('Volumetric H_2O Mixing Ratio')
%axis([0.5 1.3 1e-6 1])
%pause

%hold on
%plot(TGO, FNET)
%title('NET FLUX')
%xlabel('Surface Temperature (K)')
%ylabel('Net outgoing Flux (W/m^2)')