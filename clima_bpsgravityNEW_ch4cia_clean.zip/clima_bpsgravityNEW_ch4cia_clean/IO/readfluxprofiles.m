clear all;clc

% These two inputs depend on the clima_allout.tab file of interest.
layers= 101
skip = 132
[J PF ALT FTOTAL FTIR FDNIR FUPIR FTSOL FDNSOL FUPSOL DIVF]=textread('clima_allout_425K.tab','%f %f %f %f %f %f %f %f %f %f %f', layers, 'headerlines',skip)

FDNSOL = FDNSOL/1000.
FUPSOL = FUPSOL/1000.
FDNIR = FDNIR/1000.
FUPIR = FUPIR/1000.

subplot 311
semilogy(FDNSOL,PF)
hold on
semilogy(FUPSOL, PF)
set(gca,'Ydir','reverse')
xlabel('Solar fluxes (W/m^2)')
ylabel('Pressure (bar)')

hold on


subplot 312
semilogy(FDNIR,PF)
hold on
semilogy(FUPIR,PF)
set(gca,'Ydir', 'reverse')
xlabel('Thermal fluxes (W/m^2)')
ylabel('Pressure (bar)')


FNETSOL = FDNSOL - FUPSOL
FNETIR = FDNIR - FUPIR

subplot 313
semilogy(FNETSOL,PF)
hold on
semilogy(FNETIR,PF)
set(gca,'Ydir', 'reverse')
xlabel('Net fluxes (W/m^2)')
ylabel('Pressure (bar)')
hold on